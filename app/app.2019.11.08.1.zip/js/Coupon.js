/**
 * Created by sav on 2019/11/4.
 */
(function(){

    var $doms = {},
        _borderSize =
        {
            mobile: {w: 650, h: 1248, r: 50},
            pc: {w: 640, h: 833, r: 20}
        },
        _isInit = false;

    var self = window.Coupon =
    {
        init: function()
        {
            if(_isInit) return;
            _isInit = true;

            var id = "#coupon";

            var $container = $(id);

            $container.find(".btn-back").on("click", function(event)
            {
                event.preventDefault();

                PopupMangaer.close(id, function()
                {
                    MainPage.scrollToContent("/Index");
                });
            });

            PopupMangaer.regist(id, $container, {containerColor: "linear-gradient(0deg, rgba(76,3,97,1) 51%, rgba(129,26,162,1) 80%)"});

            //var $svg = $container.find(".content-border");

            Main.addSvgBorder($container.find(".content-all"), _borderSize);
        }
    };

}());