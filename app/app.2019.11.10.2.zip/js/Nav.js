/**
 * Created by sav on 2019/11/3.
 */
(function(){

    var $doms = {},
        _isNavOpen = false;

    var self = window.Nav =
    {
        init: function()
        {

            // trigger
            (function(){

                $doms.container = $("#nav");

                $doms.container.find(".btn-trigger").on("click", function(event)
                {
                    event.preventDefault();

                    self.switchNav(true);
                });

                $doms.container.find(".nav-logo").on("click", function(event)
                {
                    event.preventDefault();

                    MainPage.scrollToContent("/Index");
                });

            }());


            // container
            (function(){

                $doms.navContainer = $("#nav-container");

                var id = "nav";

                var $container = $doms.navContainer;

                $container.find(".nav-btn-close").on("click", function(event)
                {
                    event.preventDefault();

                    self.switchNav(false);
                });

                PopupMangaer.regist(id, $container, {containerColor: "rgba(64, 11, 97, .95)"});

            }());

            // buttons
            (function(){

                var $container = $doms.navContainer;

                setupButton(1, function()
                {
                    self.switchNav(false, function()
                    {
                        MainPage.scrollToContent("/Questionnaire");
                    });
                });

                setupButton(4, function()
                {
                    self.switchNav(false, function()
                    {
                        PopupMangaer.open("#coupon");
                    });
                });


                function setupButton(index, func)
                {
                    $container.find(".btn-" + index).on("click", function(event)
                    {
                        event.preventDefault();

                        func.call();
                    });
                }

            }());

            ScrollListener.addListener("nav", function(bound)
            {
                var triggerV2 = (bound.top > 120);

                $doms.container.toggleClass("v2-mode", triggerV2);

            }).update();
        },

        switchNav: function(isOpen, cb)
        {
            if(isOpen === _isNavOpen) return;
            _isNavOpen = isOpen;

            //$doms.navContainer.toggleClass("open-mode", _isNavOpen);
            //MainPage.setSceneScrollLock(_isNavOpen);

            if(_isNavOpen)
            {
                PopupMangaer.open("nav", cb);
            }
            else
            {
                PopupMangaer.close("nav", cb);
            }
        }
    };

}());